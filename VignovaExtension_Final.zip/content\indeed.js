/**
 * Vignova Extension — Indeed Content Script
 * Detects job listing pages and injects "Tailor Resume" button.
 *
 * Indeed DOM structure (may change):
 * - Job title:       .jobsearch-JobInfoHeader-title / h1[data-testid="jobsearch-JobInfoHeader-title"]
 * - Company:         [data-testid="inlineHeader-companyName"] / .jobsearch-InlineCompanyRating-companyHeader
 * - Description:     #jobDescriptionText / .jobsearch-jobDescriptionText
 * - Actions area:    .jobsearch-JobInfoHeader-title-container / near the Apply button
 */

(function () {
    "use strict";

    // ─── Overlay manager (defensive) ───
    // If overlay.js failed to load (partial injection after an extension
    // update / reload), fall back to a no-op stub instead of crashing the
    // whole content script with "Vignova_Overlay is not defined".
    const Vignova_Overlay = window.Vignova_Overlay || {
        showLoading() {},
        showError(msg) { console.warn("[Vignova] Overlay unavailable:", msg); },
        showAllResults() {},
        remove() {},
    };

    // ─── Extension Context Validation ───
    function hasValidExtensionContext() {
        return typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id;
    }


    function setBtnContent(btn, iconClass, iconStr, text) {
        btn.textContent = "";
        if (iconClass) {
            const span = document.createElement("span");
            span.className = iconClass;
            span.textContent = iconStr;
            btn.appendChild(span);
        }
        if (text) btn.appendChild(document.createTextNode(" " + text.trim()));
    }

    const BUTTON_ID = "vignova-indeed-tailor-btn";
    const SAVE_BUTTON_ID = "vignova-indeed-save-btn";

    let isProcessing = false;

    // ─── Applied/Saved badges on Indeed job cards ───
    const CARD_BADGE_ATTR = "data-vignova-badge";

    async function stampJobListCards() {
        // Indeed job cards in the results list
        const cards = document.querySelectorAll(
            `.job_seen_beacon:not([${CARD_BADGE_ATTR}]), .tapItem:not([${CARD_BADGE_ATTR}])`
        );
        if (!cards.length) return;

        const storage = await chrome.storage.local.get(null);

        for (const card of cards) {
            const jobLink = card.querySelector("a[data-jk], a[id*='job_']");
            const jk = jobLink?.getAttribute("data-jk") || (jobLink?.href.match(/jk=([^&]+)/)?.[1]);
            card.setAttribute(CARD_BADGE_ATTR, "1");
            if (!jk) continue;

            const matchKey = Object.keys(storage).find(k => k.includes(jk));
            const state = matchKey ? storage[matchKey] : null;
            if (!state?.tailored && !state?.saved) continue;

            const existingBadge = card.querySelector(".vignova-card-badge");
            if (existingBadge) continue;

            const badge = document.createElement("span");
            badge.className = "vignova-card-badge";
            badge.style.cssText = `
                display:inline-block; margin-left:6px;
                background:${state.tailored ? "#166534" : "#1e3a5f"};
                color:${state.tailored ? "#bbf7d0" : "#bae6fd"};
                font-size:9px; font-weight:700; padding:2px 6px;
                border-radius:6px; letter-spacing:0.3px; vertical-align:middle;
            `;
            badge.textContent = state.tailored ? "✓ Tailored" : "Saved";

            const titleEl = card.querySelector("h2, .jobTitle");
            if (titleEl) titleEl.appendChild(badge);
        }
    }

    // ─── Observe DOM Changes (Indeed partially SPA) ───
    const observer = new MutationObserver(() => {
        if (!hasValidExtensionContext()) {
            observer.disconnect();
            return;
        }
        if (!document.getElementById(BUTTON_ID)) {
            tryInjectButton();
        }
        stampJobListCards();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });

    // Initial attempt
    setTimeout(tryInjectButton, 1500);
    setTimeout(stampJobListCards, 2000);

    // ─── Try to Inject Button ───
    function tryInjectButton() {
        const CONTAINER_ID = "vignova-indeed-container";
        // Aggressive cleanup of old dead buttons
        document.querySelectorAll("#" + CONTAINER_ID + ", .vignova-injected-container").forEach(el => {
            if (!el.isConnected) el.remove();
        });
        if (document.getElementById(CONTAINER_ID)) return;

        // Injection Point 1: Native Indeed Sticky Action Bar (Next to Apply/Save)
        let targetContainer = document.getElementById("saveJobButtonContainer");

        // Formatter fallback: Look for modern sticky header container
        if (!targetContainer) {
            const stickyHeader = document.querySelector(".jobsearch-JobInfoHeader-actions");
            if (stickyHeader) targetContainer = stickyHeader;
        }

        // Final fallback: original title block
        if (!targetContainer) {
            targetContainer = document.querySelector(".jobsearch-JobInfoHeader-title-container") ||
                document.querySelector("[data-testid='jobsearch-JobInfoHeader-title']")?.closest("div");
        }

        if (!targetContainer) {
            // Ultimate fallback to description if nothing found
            const descriptionArea = document.querySelector("#jobDescriptionText");
            if (descriptionArea) {
                injectFallback(descriptionArea);
            }
            return;
        }

        // Wrapper for buttons
        let wrapper = document.getElementById("vignova-indeed-wrapper");
        if (!wrapper) {
            wrapper = document.createElement("div");
            wrapper.id = "vignova-indeed-wrapper";
            wrapper.style.display = "flex";
            wrapper.style.alignItems = "center";
            wrapper.style.gap = "8px";
            wrapper.style.marginLeft = "12px"; // Separate from Indeed's buttons

            // If injecting into the sticky bar, just append. If title bar, insert below.
            if (targetContainer.id === "saveJobButtonContainer" || targetContainer.classList.contains("jobsearch-JobInfoHeader-actions")) {
                targetContainer.appendChild(wrapper);
            } else {
                wrapper.style.marginTop = "12px";
                wrapper.style.marginBottom = "4px";
                targetContainer.parentElement.appendChild(wrapper);
            }

            ensureContainer(wrapper);
        }
    }

    function injectFallback(descriptionArea) {
        let wrapper = document.getElementById("vignova-indeed-wrapper");
        if (!wrapper) {
            wrapper = document.createElement("div");
            wrapper.id = "vignova-indeed-wrapper";
            wrapper.style.marginBottom = "15px";
            descriptionArea.parentElement.insertBefore(wrapper, descriptionArea);
            ensureContainer(wrapper);
        }
    }

    function ensureContainer(parent) {
        const CONTAINER_ID = "vignova-indeed-container";
        let container = document.getElementById(CONTAINER_ID);
        if (!container) {
            container = document.createElement("div");
            container.id = CONTAINER_ID;
            container.className = "vignova-injected-container";
            parent.appendChild(container);

            // Render UI only on creation
            renderExtensionUI();
        }
    }

    // ─── Render Extension UI (Auth Aware) ───
    let isRenderingUI = false;

    async function renderExtensionUI() {
        if (isRenderingUI) return;
        isRenderingUI = true;

        // Check Auth
        const authStatus = await new Promise((resolve) => {
            chrome.runtime.sendMessage({ type: "GET_AUTH_STATUS" }, resolve);
        });

        const container = document.getElementById("vignova-indeed-container");
        if (!container) {
            isRenderingUI = false;
            return; // Should exist
        }

        // Clear container AFTER await to prevent async race conditions where multiple 
        // observer triggers clear an already-empty box and then all append.
        container.textContent = "";

        if (!authStatus?.isLoggedIn) {
            // Render Login Button
            const loginBtn = document.createElement("button");
            loginBtn.className = "vignova-tailor-btn vignova-btn-login";
            setBtnContent(loginBtn, "vignova-btn-icon", "🔑", "Login to Vignova to View Options");
            loginBtn.style.backgroundColor = "#333";
            loginBtn.onclick = () => {
                window.dispatchEvent(new CustomEvent("vignova:open-dashboard"));
            };
            container.appendChild(loginBtn);
        } else {
            // Render Action Buttons
            renderActionButtons(container);
        }

        isRenderingUI = false;
    }

    function renderActionButtons(container) {
        // 1. Tailor Button
        const tailorBtn = document.createElement("button");
        tailorBtn.id = BUTTON_ID;
        tailorBtn.className = "vignova-tailor-btn";
        setBtnContent(tailorBtn, "vignova-btn-icon", "⚡", "Tailor Resume");
        tailorBtn.addEventListener("click", handleTailorClick);

        // 2. Save Button
        const saveBtn = document.createElement("button");
        saveBtn.id = SAVE_BUTTON_ID;
        saveBtn.className = "vignova-save-btn";
        setBtnContent(saveBtn, "vignova-btn-icon", "💾", "Save to Dashboard");
        saveBtn.addEventListener("click", handleSaveClick);

        // Check stored state
        checkJobState(window.location.href, tailorBtn, saveBtn);

        // Add Vignova Branding Logo
        const logoImg = document.createElement("img");
        logoImg.src = chrome.runtime.getURL("icons/logo.png");
        logoImg.style.height = "24px";
        logoImg.style.width = "auto";
        logoImg.style.objectFit = "contain";
        logoImg.style.marginLeft = "4px";
        logoImg.style.marginRight = "8px";
        logoImg.style.borderRadius = "2px";
        logoImg.title = "Vignova AI";
        container.appendChild(logoImg);

        // 0. Match Score Badge
        const scoreBadge = document.createElement("div");
        scoreBadge.className = "vignova-score-badge";
        scoreBadge.textContent = "";
        const spinner = document.createElement("div");
        spinner.className = "vignova-score-loading";
        scoreBadge.appendChild(spinner); // Loading spinner
        scoreBadge.title = "Calculating Match Score...";

        container.appendChild(scoreBadge);
        container.appendChild(tailorBtn);
        container.appendChild(saveBtn);

        // Fetch Score
        fetchAndDisplayScore(scoreBadge);
    }

    // ─── Extract salary / deadline from JD text ───
    function extractJobMeta(text) {
        if (!text) return {};
        const result = {};
        const salaryRe = [
            /(?:\$|€|£|₹|USD|EUR|GBP)\s*[\d,]+(?:k)?(?:\s*[-–]\s*(?:\$|€|£|₹|USD|EUR|GBP)?\s*[\d,]+(?:k)?)?(?:\s*\/?\s*(?:yr|year|hour|hr|annum|month))?/i,
            /[\d,]+k?\s*[-–]\s*[\d,]+k?\s*(?:per year|per annum|annually|a year|\/yr|\/year)/i,
            /(?:salary|compensation|pay|package|tc|total comp)[:\s]+(?:up to\s+)?(?:\$|€|£|₹|USD|EUR|GBP)?\s*[\d,]+(?:k)?(?:\s*[-–]\s*(?:\$|€|£|₹|USD|EUR|GBP)?\s*[\d,]+(?:k)?)?/i,
        ];
        for (const re of salaryRe) {
            const m = text.match(re);
            if (m) { result.salary = m[0].trim(); break; }
        }
        const deadlineRe = /(?:apply\s+by|deadline|closing\s+date|applications?\s+close[sd]?|position\s+closes?)[:\s]+([A-Z][a-z]+ \d{1,2},?\s*\d{4}|\d{1,2}[\/.\-]\d{1,2}[\/.\-]\d{2,4})/i;
        const dm = text.match(deadlineRe);
        if (dm) result.deadline = dm[1].trim();
        return result;
    }

    // ─── Fetch & Display Score ───
    async function fetchAndDisplayScore(badge) {
        const jobData = scrapeIndeedJob();
        if (!jobData.jobDescription) {
            // Indeed sometimes lazy loads description
            badge.textContent = "?";
            badge.title = "Scroll down to load description";
            return;
        }

        try {
            const { vignova_agent_profile: profile } = await chrome.storage.local.get(['vignova_agent_profile']);
            const response = VignovaLocalScorer.score(jobData.jobDescription, profile || null);
            const jobMeta = extractJobMeta(jobData.jobDescription);

            if (response && response.success) {
                const score = response.score;

                // Categorical Mapping — realistic thresholds
                let categoryText = "";
                badge.classList.remove("high", "medium", "low", "very-high", "very-low");

                if (score >= 75) {
                    categoryText = "Very High";
                    badge.classList.add("very-high");
                } else if (score >= 55) {
                    categoryText = "High";
                    badge.classList.add("high");
                } else if (score >= 35) {
                    categoryText = "Medium";
                    badge.classList.add("medium");
                } else if (score >= 20) {
                    categoryText = "Low";
                    badge.classList.add("low");
                } else {
                    categoryText = "Very Low";
                    badge.classList.add("very-low");
                }

                badge.textContent = categoryText;

                // Add Matched Keywords
                let matchedKeywordsHtml = "";
                const matchedKws = response.breakdown.matching_keywords || [];
                if (matchedKws.length > 0) {
                    const kwPills = matchedKws.slice(0, 25).map(k => `<span class="vignova-kw-pill">${k}</span>`).join("");
                    matchedKeywordsHtml = `
                        <div class="vignova-tt-row" style="margin-top:12px; border-top:1px solid #3f3f46; padding-top:12px; display:block;">
                            <span class="vignova-tt-label" style="display:block; margin-bottom:6px;">Keyword Matches (${matchedKws.length})</span>
                            <div style="display:flex; flex-wrap:wrap; gap:6px;">${kwPills}</div>
                        </div>
                    `;
                }

                // Add Missing Keywords
                let missingKeywordsHtml = "";
                const missingKws = response.breakdown.missing_keywords || [];
                if (missingKws.length > 0) {
                    const missingPills = missingKws.slice(0, 25).map(k => `<span class="vignova-kw-pill vignova-kw-missing">${k}</span>`).join("");
                    missingKeywordsHtml = `
                        <div class="vignova-tt-row" style="margin-top:12px; border-top:1px solid #3f3f46; padding-top:12px; display:block;">
                            <span class="vignova-tt-label" style="display:block; margin-bottom:6px;">What's Missing (${missingKws.length})</span>
                            <div style="display:flex; flex-wrap:wrap; gap:6px;">${missingPills}</div>
                        </div>
                    `;
                }

                // Create Advanced HTML Tooltip String
                const sem = response.breakdown.semantic;
                const kw = response.breakdown.keyword;
                const domainRel = response.breakdown.domain_relevance || 100;
                const metaHtml = (jobMeta.salary || jobMeta.deadline) ? `
                    <div class="vignova-tt-row" style="margin-top:10px; border-top:1px solid #3f3f46; padding-top:10px; gap:8px; flex-wrap:wrap;">
                        ${jobMeta.salary ? `<span style="background:rgba(16,185,129,0.15);border:1px solid rgba(16,185,129,0.3);color:#6ee7b7;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600;">💰 ${jobMeta.salary}</span>` : ""}
                        ${jobMeta.deadline ? `<span style="background:rgba(251,191,36,0.15);border:1px solid rgba(251,191,36,0.3);color:#fde68a;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600;">📅 Apply by ${jobMeta.deadline}</span>` : ""}
                    </div>` : "";

                const tooltipHTML = `
                    <div class="vignova-tt-header">Match Breakdown (${score}/100)</div>
                    ${metaHtml}
                    <div class="vignova-tt-row">
                        <span class="vignova-tt-label">Vibe & Theory</span>
                        <div class="vignova-tt-bar-bg"><div class="vignova-tt-bar-fill" style="width: ${sem}%; background: #3b82f6;"></div></div>
                        <span class="vignova-tt-val">${sem}%</span>
                    </div>
                    <div class="vignova-tt-row">
                        <span class="vignova-tt-label">Keywords</span>
                        <div class="vignova-tt-bar-bg"><div class="vignova-tt-bar-fill" style="width: ${kw}%; background: #10b981;"></div></div>
                        <span class="vignova-tt-val">${kw}%</span>
                    </div>
                    <div class="vignova-tt-row">
                        <span class="vignova-tt-label">Domain Fit</span>
                        <div class="vignova-tt-bar-bg"><div class="vignova-tt-bar-fill" style="width: ${domainRel}%; background: ${domainRel >= 80 ? '#10b981' : domainRel >= 50 ? '#f59e0b' : '#ef4444'};"></div></div>
                        <span class="vignova-tt-val">${domainRel}%</span>
                    </div>
                    ${matchedKeywordsHtml}
                    ${missingKeywordsHtml}
                `;

                // Store the HTML data
                badge.setAttribute("data-tooltip-html", tooltipHTML);
                badge.removeAttribute("data-tooltip");
                badge.title = "";

                // Add Hover Listeners for Global Tooltip
                badge.addEventListener("mouseenter", showGlobalTooltip);
                badge.addEventListener("mouseleave", hideGlobalTooltip);

            } else {
                badge.textContent = "!";
                badge.title = "Failed to calculate score";
            }
        } catch (e) {
            console.error(e);
            badge.textContent = "!";
        }
    }

    // ─── Global Tooltip Logic ───
    let globalTooltipEl = null;

    function showGlobalTooltip(e) {
        const badge = e.currentTarget;
        const html = badge.getAttribute("data-tooltip-html");
        if (!html) return;

        if (!globalTooltipEl) {
            globalTooltipEl = document.createElement("div");
            globalTooltipEl.className = "vignova-tooltip-content global-tooltip";
            document.body.appendChild(globalTooltipEl);
        }

        const doc = new DOMParser().parseFromString(html, "text/html");
        globalTooltipEl.textContent = "";
        while (doc.body.firstChild) {
            globalTooltipEl.appendChild(doc.body.firstChild);
        }

        // Show slightly to calculate dimensions
        globalTooltipEl.style.visibility = "hidden";
        globalTooltipEl.style.opacity = "0";
        globalTooltipEl.classList.add("show");

        // Calculate position
        const rect = badge.getBoundingClientRect();

        // Position to the right of the badge
        const top = rect.top + (rect.height / 2) - (globalTooltipEl.offsetHeight / 2);
        const left = rect.right + 12; // 12px gap

        globalTooltipEl.style.top = `${top}px`;
        globalTooltipEl.style.left = `${left}px`;

        // Render
        globalTooltipEl.style.visibility = "visible";
        globalTooltipEl.style.opacity = "1";
    }

    function hideGlobalTooltip() {
        if (globalTooltipEl) {
            globalTooltipEl.classList.remove("show");
            globalTooltipEl.style.opacity = "0";
            globalTooltipEl.style.visibility = "hidden";
        }
    }

    // ─── Check Stored State ───
    function checkJobState(url, tailorBtn, saveBtn) {
        chrome.storage.local.get([url], (result) => {
            const data = result[url];
            if (data?.tailored) {
                setBtnContent(tailorBtn, "vignova-btn-icon", "✅", "Resume Created");
                tailorBtn.classList.add("success");
                tailorBtn.title = "You have already tailored a resume for this job.";
            }

            if (data?.saved) {
                setBtnContent(saveBtn, "vignova-btn-icon", "👁️", "View in Dashboard");
                saveBtn.classList.add("success");
                saveBtn.onclick = () => {
                    window.open(`${Vignova_API_BASE}/dashboard`, "_blank");
                };
            }
        });
    }

    // ─── Handle Save Click ───
    async function handleSaveClick() {
        const btn = document.getElementById(SAVE_BUTTON_ID);
        if (btn.classList.contains("success")) return;

        btn.disabled = true;
        setBtnContent(btn, "vignova-btn-spinner", "", "Saving...");

        const jobData = scrapeIndeedJob();
        // Use full URL to preserve 'vjk' or 'jk' parameters which are crucial for Indeed
        const currentUrl = window.location.href;

        try {
            const result = await chrome.runtime.sendMessage({
                type: "API_SAVE_JOB",
                data: {
                    jobTitle: jobData.jobTitle,
                    company: jobData.company,
                    location: jobData.location,
                    jobUrl: currentUrl,
                    description: jobData.jobDescription,
                    source: "INDEED"
                }
            });

            if (result.success) {
                // Save state
                const update = {};
                update[currentUrl] = { saved: true };
                chrome.storage.local.get([currentUrl], (current) => {
                    const existing = current[currentUrl] || {};
                    chrome.storage.local.set({
                        [currentUrl]: { ...existing, saved: true, jobId: result.jobId }
                    });
                });

                setBtnContent(btn, "vignova-btn-icon", "👁️", "View in Dashboard");
                btn.classList.add("success");
                btn.disabled = false;
                btn.onclick = () => {
                    window.open("https://app.vignova.io/dashboard", "_blank");
                };
            } else {
                setBtnContent(btn, null, null, "❌ Failed");
                setTimeout(() => {
                    setBtnContent(btn, "vignova-btn-icon", "💾", "Save to Vignova Dashboard");
                    btn.disabled = false;
                }, 2000);
                alert("Failed to save: " + (result.error || "Unknown error"));
            }
        } catch (err) {
            console.error(err);
            setBtnContent(btn, null, null, "❌ Error");
            btn.disabled = false;
        }
    }

    // ─── Handle Button Click ───
    async function handleTailorClick(e) {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }

        if (isProcessing) return;
        isProcessing = true;

        const btn = document.getElementById(BUTTON_ID);
        if (!btn) {
            isProcessing = false;
            return;
        }

        // Check if logged in (with timeout)
        let authStatus = null;
        try {
            authStatus = await Promise.race([
                new Promise((resolve) => chrome.runtime.sendMessage({ type: "GET_AUTH_STATUS" }, resolve)),
                new Promise((_, reject) => setTimeout(() => reject(new Error("Auth timeout")), 5000))
            ]);
        } catch (err) {
            console.error("Auth check failed:", err);
            alert("Connection to extension failed. Please reload the page.");
            isProcessing = false;
            return;
        }

        if (!authStatus?.isLoggedIn) {
            setBtnContent(btn, "vignova-btn-icon", "🔑", "Login Required");
            btn.classList.add("vignova-btn-login");
            isProcessing = false;
            window.dispatchEvent(new CustomEvent("vignova:open-dashboard"));
            return;
        }

        // Update button to loading
        btn.disabled = true;
        setBtnContent(btn, "vignova-btn-spinner", "", "Generating...");

        // Show overlay
        Vignova_Overlay.showLoading();

        // Scrape job data
        const jobData = scrapeIndeedJob();

        if (!jobData.jobDescription) {
            Vignova_Overlay.showError("Could not find the job description. Please scroll down to load it and try again.");
            resetButton();
            return;
        }

        const currentUrl = window.location.href;

        // Call API via background service worker (avoids local network prompt)
        try {
            const result = await chrome.runtime.sendMessage({
                type: "API_GENERATE_ALL",
                data: {
                    jobDescription: jobData.jobDescription,
                    jobTitle: jobData.jobTitle,
                    company: jobData.company,
                    jobUrl: currentUrl,
                    source: "INDEED",
                },
            });

            if (result.success) {
                const fileName = `${(jobData.company || "Resume").replace(/[^a-zA-Z0-9]/g, "_")}_Resume.pdf`;
                Vignova_Overlay.showAllResults(
                    result.pdfBase64,
                    result.coverLetter,
                    result.draftEmail,
                    fileName,
                    result.credits_remaining
                );
                setBtnContent(btn, "vignova-btn-icon", "✅", "Resume Created");
                btn.classList.add("success");

                // Save state
                chrome.storage.local.get([currentUrl], (current) => {
                    const existing = current[currentUrl] || {};
                    chrome.storage.local.set({
                        [currentUrl]: { ...existing, tailored: true }
                    });
                });

            } else {
                Vignova_Overlay.showError(
                    result.error || "Failed to generate resume.",
                    () => {
                        resetButton();
                    }
                );
                resetButton();
            }
        } catch (err) {
            console.error("[Vignova Indeed]", err);
            Vignova_Overlay.showError(
                "Could not connect to Vignova. Make sure the server is running.",
                () => {
                    resetButton();
                }
            );
            resetButton();
        }
    }

    // ─── Scrape Job Data from Indeed DOM ───
    function scrapeIndeedJob() {
        // Job Title
        const jobTitle =
            document.querySelector("[data-testid='jobsearch-JobInfoHeader-title']")?.innerText?.trim() ||
            document.querySelector(".jobsearch-JobInfoHeader-title")?.innerText?.trim() ||
            document.querySelector("h1")?.innerText?.trim() ||
            "";

        // Company Name
        const company =
            document.querySelector("[data-testid='inlineHeader-companyName']")?.innerText?.trim() ||
            document.querySelector(".jobsearch-InlineCompanyRating-companyHeader a")?.innerText?.trim() ||
            document.querySelector("[data-company-name]")?.getAttribute("data-company-name") ||
            document.querySelector(".jobsearch-CompanyInfoWithoutHeaderImage a")?.innerText?.trim() ||
            "";

        const location =
            document.querySelector("[data-testid='job-location']")?.innerText?.trim() ||
            document.querySelector(".jobsearch-JobInfoHeader-subtitle div")?.innerText?.trim() ||
            "";

        // Job Description
        const descriptionEl =
            document.querySelector("#jobDescriptionText") ||
            document.querySelector(".jobsearch-jobDescriptionText") ||
            document.querySelector("[id='jobDescriptionText']");

        let jobDescription = descriptionEl?.innerText?.trim() || "";
        if (jobDescription) {
            // Remove common unnecessary words from Indeed scraping
            jobDescription = jobDescription
                .replace(/Report job\s*$/i, '')
                .replace(/Report this job\s*$/i, '')
                .trim();
            jobDescription = jobDescription.replace(/\n{3,}/g, '\n\n');
        }

        // descriptionEl returned so the review panel can highlight it
        return { jobTitle, company, jobDescription, location, descriptionEl };
    }

    // ─── Reset Button State ───
    function resetButton() {
        isProcessing = false;
        const btn = document.getElementById(BUTTON_ID);
        if (btn && !btn.classList.contains("success")) {
            btn.disabled = false;
            btn.classList.remove("vignova-btn-login");
            setBtnContent(btn, "vignova-btn-icon", "⚡", "Tailor Resume");
        }
    }

    // ─── Listen for Auth Changes ───
    chrome.runtime.onMessage.addListener((message) => {
        if (message.type === "AUTH_STATE_CHANGED") {
            renderExtensionUI();
        }
    });
})();
