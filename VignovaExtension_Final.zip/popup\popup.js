/**
 * Vignova Extension — Popup Logic v2
 * Handles: Tabs, Autofill, Keyword Score, Profile, Job Save, Cover Letter
 */

const copyText = (text) => {
    if (!text) return;
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.left = "-999999px";
    textArea.style.top = "-999999px";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
        document.execCommand('copy');
    } catch (err) {
        console.error('execCommand copy failed', err);
    }
    textArea.remove();
};


document.addEventListener("DOMContentLoaded", async () => {
    let isPremium = false;
    let cachedProfile = null;

    // ═══════════════════════════════════════════
    //  ONBOARDING GUIDE (First-time users)
    // ═══════════════════════════════════════════
    const onboardingOverlay = document.getElementById("onboardingOverlay");
    const onboardingResult = await chrome.storage.local.get(["vignova_onboarding_done"]);

    if (!onboardingResult.vignova_onboarding_done && onboardingOverlay) {
        onboardingOverlay.style.display = "flex";

        let currentStep = 0;
        const totalSteps = 5;
        const slides = onboardingOverlay.querySelectorAll(".vignova-onboarding-slide");
        const dots = onboardingOverlay.querySelectorAll(".vignova-onboarding-dot");
        const prevBtn = document.getElementById("onboardingPrevBtn");
        const nextBtn = document.getElementById("onboardingNextBtn");
        const stepLabel = document.getElementById("onboardingStepLabel");

        const goToStep = (step, direction = "forward") => {
            const prevStep = currentStep;

            // Animate old slide out
            slides[prevStep].classList.remove("active");
            slides[prevStep].classList.add(direction === "forward" ? "exit-left" : "exit-right");
            setTimeout(() => {
                slides[prevStep].classList.remove("exit-left", "exit-right");
            }, 450);

            currentStep = step;

            // Animate new slide in: set starting position, then animate to center
            const newSlide = slides[currentStep];
            newSlide.style.transition = "none";
            newSlide.style.transform = direction === "forward" ? "translateX(40px)" : "translateX(-40px)";
            newSlide.style.opacity = "0";
            newSlide.classList.add("active");

            // Double rAF ensures the browser has painted the starting position
            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    newSlide.style.transition = "";
                    newSlide.style.transform = "translateX(0)";
                    newSlide.style.opacity = "1";

                    // Clean up inline styles after animation completes
                    setTimeout(() => {
                        newSlide.style.transform = "";
                        newSlide.style.opacity = "";
                        newSlide.style.transition = "";
                    }, 450);
                });
            });

            // Update dots
            dots.forEach((dot, i) => {
                dot.classList.remove("active", "completed");
                if (i === currentStep) dot.classList.add("active");
                else if (i < currentStep) dot.classList.add("completed");
            });

            // Update step label
            stepLabel.textContent = `${currentStep + 1} of ${totalSteps}`;

            // Update button states
            prevBtn.disabled = currentStep === 0;

            // Last step: hide next button (Get Started button takes over)
            if (currentStep === totalSteps - 1) {
                nextBtn.style.display = "none";
            } else {
                nextBtn.style.display = "flex";
            }
        };

        const completeOnboarding = async () => {
            await chrome.storage.local.set({ vignova_onboarding_done: true });
            onboardingOverlay.style.opacity = "0";
            onboardingOverlay.style.transition = "opacity 0.3s ease";
            setTimeout(() => {
                onboardingOverlay.style.display = "none";
            }, 300);
        };

        nextBtn.addEventListener("click", () => {
            if (currentStep < totalSteps - 1) {
                goToStep(currentStep + 1, "forward");
            }
        });

        prevBtn.addEventListener("click", () => {
            if (currentStep > 0) {
                goToStep(currentStep - 1, "backward");
            }
        });

        // Dot clicks for direct navigation
        dots.forEach((dot) => {
            dot.addEventListener("click", () => {
                const target = parseInt(dot.dataset.step);
                if (target !== currentStep) {
                    goToStep(target, target > currentStep ? "forward" : "backward");
                }
            });
        });

        document.getElementById("onboardingSkipBtn")?.addEventListener("click", completeOnboarding);
        document.getElementById("onboardingStartBtn")?.addEventListener("click", completeOnboarding);
    }

    // ─── Element References ───
    const loginView = document.getElementById("loginView");
    const dashboardView = document.getElementById("dashboardView");
    const upgradeView = document.getElementById("upgradeView");
    const jdReviewView = document.getElementById("jdReviewView");
    const loginForm = document.getElementById("loginForm");
    const loginBtn = document.getElementById("loginBtn");
    const loginBtnText = document.getElementById("loginBtnText");
    const loginSpinner = document.getElementById("loginSpinner");
    const loginError = document.getElementById("loginError");
    const logoutBtn = document.getElementById("logoutBtn");
    const upgradeBackBtn = document.getElementById("upgradeBackBtn");
    const copyToast = document.getElementById("copyToast");
    const interviewPrepView = document.getElementById("interviewPrepView");

    // ─── View Switching ───
    function showView(view) {
        [loginView, dashboardView, upgradeView, jdReviewView, interviewPrepView].forEach((v) => (v.style.display = "none"));
        view.style.display = "";
    }

    // ─── Premium Gate Modal ───
    const premiumModal = document.getElementById("premiumModal");
    function showUpgradeModal(featureName) {
        document.getElementById("premiumModalFeatureName").textContent = featureName;
        premiumModal.style.display = "flex";
    }
    document.getElementById("premiumModalClose")?.addEventListener("click", () => {
        premiumModal.style.display = "none";
    });
    premiumModal?.addEventListener("click", (e) => {
        if (e.target === premiumModal) premiumModal.style.display = "none";
    });

    // ─── Tab System ───
    const tabs = document.querySelectorAll(".vignova-tab");
    const tabContents = document.querySelectorAll(".vignova-tab-content");

    tabs.forEach((tab) => {
        tab.addEventListener("click", () => {
            tabs.forEach((t) => t.classList.remove("active"));
            tabContents.forEach((c) => c.classList.remove("active"));
            tab.classList.add("active");
            const tabName = tab.dataset.tab;
            const target = document.getElementById("tab-" + tabName);
            if (target) target.classList.add("active");

            // Trigger keyword analysis automatically if switching to it
            if (tabName === "keywords") {
                runKeywordAnalysis();
            }
        });
    });

    // ═══════════════════════════════════════════
    //  AUTH BOOTSTRAP
    //  The extension mirrors the website session: if app.vignova.io is signed
    //  in as a different user than the stored token, we follow the website.
    //  All session lookups run in the service worker (the SameSite cookie
    //  never attaches to fetches made from this iframed popup).
    // ═══════════════════════════════════════════

    let webSession = null;

    async function refreshWebSession() {
        try {
            webSession = await chrome.runtime.sendMessage({ type: "WEB_SESSION_PROBE" });
        } catch (_) {
            webSession = null;
        }
        return webSession;
    }

    // Populates the "Continue as …" card when the website has an active session
    function showLoginView() {
        const card = document.getElementById("webSessionCard");
        const divider = document.getElementById("webSessionDivider");
        const hasSession = !!(webSession?.loggedIn && webSession.user);
        if (card) {
            card.style.display = hasSession ? "flex" : "none";
            if (divider) divider.style.display = hasSession ? "flex" : "none";
            if (hasSession) {
                const name = webSession.user.name || webSession.user.email || "your account";
                document.getElementById("webSessionName").textContent = name;
                document.getElementById("webSessionEmail").textContent =
                    webSession.user.email || "Signed in on vignova.io";
                document.getElementById("webSessionAvatar").textContent =
                    (name.trim()[0] || "V").toUpperCase();
            }
        }
        showView(loginView);
    }

    const stored = await chrome.storage.local.get(["vignova_token", "vignova_user", "vignova_signed_out"]);
    await refreshWebSession();

    let authenticated = !!stored.vignova_token;

    if (authenticated && webSession?.loggedIn && webSession.user?.email &&
        stored.vignova_user?.email && webSession.user.email !== stored.vignova_user.email) {
        // The website switched accounts — follow it so both always show the same user
        await chrome.runtime.sendMessage({ type: "WEB_SESSION_ADOPT" }).catch(() => null);
    } else if (!authenticated && webSession?.loggedIn && !stored.vignova_signed_out) {
        // Silent auto-login from the active website session
        const adopted = await chrome.runtime.sendMessage({ type: "WEB_SESSION_ADOPT" }).catch(() => null);
        authenticated = !!adopted?.success;
    }

    if (authenticated) {
        await loadDashboard();
    } else {
        showLoginView();
    }

    // ─── Social Logins (OAuth tab flow) ───
    const PROVIDER_URLS = {
        googleLoginBtn:   "https://app.vignova.io/api/auth/signin/google",
        linkedinLoginBtn: "https://app.vignova.io/api/auth/signin/linkedin",
    };

    const showLoginError = (msg) => {
        loginError.innerHTML = `<span style="font-size:15px;margin-right:6px;">⚠️</span>${msg}`;
        loginError.style.display = "flex";
        loginError.style.alignItems = "center";
    };

    const tryFetchExtensionToken = async () => {
        // Attempt A: via service worker, where the session cookie attaches.
        // On success the worker stores the token and clears stale caches itself.
        try {
            const data = await chrome.runtime.sendMessage({ type: "WEB_SESSION_ADOPT" });
            if (data?.success) return { adopted: true, user: data.user };
        } catch (_) {}

        // Attempt B: inject into an open app.vignova.io tab
        try {
            const tabs = await chrome.tabs.query({ url: "https://app.vignova.io/*" });
            if (tabs.length > 0 && tabs[0].id) {
                const results = await chrome.scripting.executeScript({
                    target: { tabId: tabs[0].id },
                    func: async () => {
                        try { const r = await fetch("/api/extension/session-token"); return await r.json(); } catch { return null; }
                    }
                });
                const data = results[0]?.result;
                if (data?.token) {
                    // Store via the service worker so stale caches are cleared
                    await chrome.runtime.sendMessage({
                        type: "ADOPT_TOKEN",
                        data: { token: data.token, user: data.user },
                    });
                    return { adopted: true, user: data.user };
                }
            }
        } catch (_) {}

        return null;
    };

    // ─── Continue with the active website session ───
    document.getElementById("webSessionCard")?.addEventListener("click", async (e) => {
        const card = e.currentTarget;
        card.disabled = true;
        try {
            const adopted = await chrome.runtime.sendMessage({ type: "WEB_SESSION_ADOPT" });
            if (adopted?.success) {
                await loadDashboard();
            } else {
                // Session expired since the probe — hide the card, ask for credentials
                webSession = null;
                showLoginView();
                showLoginError("That session has expired. Please sign in again.");
            }
        } catch (_) {
            showLoginError("Can't reach Vignova right now. Please try again.");
        } finally {
            card.disabled = false;
        }
    });

    const handleSocialLogin = async (e) => {
        const btn = e.currentTarget;
        const providerUrl = PROVIDER_URLS[btn.id];
        const originalHTML = btn.innerHTML;

        btn.disabled = true;
        btn.innerHTML = `<span class="vignova-spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;"></span> Opening sign-in…`;
        loginError.style.display = "none";

        try {
            // Open the OAuth provider sign-in page in a visible tab
            const authTab = await chrome.tabs.create({ url: providerUrl, active: true });

            btn.innerHTML = `<span class="vignova-spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;"></span> Waiting for sign-in…`;

            // Watch for the tab to land on the Vignova dashboard (= login succeeded)
            const tokenData = await new Promise((resolve) => {
                const TIMEOUT_MS = 120_000; // 2 min
                let resolved = false;
                const done = (val) => {
                    if (resolved) return;
                    resolved = true;
                    chrome.tabs.onUpdated.removeListener(onUpdated);
                    chrome.tabs.onRemoved.removeListener(onRemoved);
                    resolve(val);
                };

                const onUpdated = async (tabId, changeInfo, tab) => {
                    if (tabId !== authTab.id || changeInfo.status !== "complete") return;
                    const url = tab.url || "";
                    // Redirect to dashboard means auth was successful
                    if (url.startsWith("https://app.vignova.io/dashboard") || url.startsWith("https://app.vignova.io/onboarding")) {
                        try { await chrome.tabs.remove(tabId); } catch (_) {}
                        const data = await tryFetchExtensionToken();
                        done(data);
                    }
                };
                const onRemoved = (tabId) => { if (tabId === authTab.id) done(null); };

                chrome.tabs.onUpdated.addListener(onUpdated);
                chrome.tabs.onRemoved.addListener(onRemoved);
                setTimeout(() => done(null), TIMEOUT_MS);
            });

            if (tokenData?.adopted) {
                await loadDashboard();
            } else {
                showLoginError("Sign-in was not completed. Please try again.");
            }
        } catch (err) {
            console.error("[Vignova] Social login error:", err);
            showLoginError("Something went wrong. Please try again.");
        } finally {
            btn.innerHTML = originalHTML;
            btn.disabled = false;
        }
    };

    document.getElementById("googleLoginBtn")?.addEventListener("click", handleSocialLogin);
    document.getElementById("linkedinLoginBtn")?.addEventListener("click", handleSocialLogin);

    // ─── Login Handler ───
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;

        loginBtn.disabled = true;
        loginBtnText.style.display = "none";
        loginSpinner.style.display = "inline-block";
        loginError.style.display = "none";

        try {
            const response = await chrome.runtime.sendMessage({
                type: "API_LOGIN",
                data: { email, password },
            });

            if (response?.success) {
                await loadDashboard();
            } else {
                const raw = response?.error || "";
                const friendly = raw.toLowerCase().includes("invalid") || raw.toLowerCase().includes("password") || raw.toLowerCase().includes("credentials")
                    ? "Incorrect email or password. Please try again."
                    : raw.toLowerCase().includes("not found") || raw.toLowerCase().includes("no user")
                    ? "No account found with that email."
                    : raw || "Sign-in failed. Please try again.";
                showLoginError(friendly);
            }
        } catch (err) {
            showLoginError("Can't reach Vignova right now. Check your connection and try again.");
        } finally {
            loginBtn.disabled = false;
            loginBtnText.style.display = "inline";
            loginSpinner.style.display = "none";
        }
    });

    // ─── Logout ───
    logoutBtn.addEventListener("click", async () => {
        // Service worker wipes token + all cached user data and remembers
        // the explicit sign-out (so we don't silently auto-login again)
        await chrome.runtime.sendMessage({ type: "SIGN_OUT" }).catch(() => {});
        // Re-probe the website session so the login view can offer "Continue as…"
        await refreshWebSession();
        showLoginView();
    });

    // ─── Upgrade Back ───
    upgradeBackBtn.addEventListener("click", () => showLoginView());

    // ─── Close ───
    document.getElementById("closeBtn")?.addEventListener("click", () => window.close());

    // ─── Settings ───
    document.getElementById("settingsBtn")?.addEventListener("click", () => {
        chrome.tabs.create({ url: "https://app.vignova.io/dashboard/settings" });
    });

    // ─── Register ───
    document.getElementById("registerLink")?.addEventListener("click", (e) => {
        e.preventDefault();
        chrome.tabs.create({ url: "https://app.vignova.io/register" });
    });

    // ═══════════════════════════════════════════
    //  LOAD DASHBOARD
    // ═══════════════════════════════════════════

    async function loadDashboard() {
        showView(dashboardView);

        try {
            const response = await chrome.runtime.sendMessage({ type: "API_GET_STATUS" });
            if (!response?.authenticated) {
                if (response?.accessDenied) {
                    showView(upgradeView);
                } else {
                    showLoginView();
                }
                return;
            }

            const data = response;

            // Credits & Plan (Profile Tab)
            const remaining = data.credits_remaining ?? 0;
            const total = data.credits_total ?? 0;
            const planType = (data.plan_type || data.plan || "free").toUpperCase();
            isPremium = planType === "PRO" || planType === "PREMIUM";

            const cr = document.getElementById("creditsRemaining");
            if (cr) cr.textContent = remaining;
            const ct = document.getElementById("creditsTotal");
            if (ct) ct.textContent = total;
            // Helper to style badges intelligently
            function applyPlanStyle(el, plan) {
                if (!el) return;
                el.textContent = plan;
                if (plan === "PRO") {
                    el.style.backgroundColor = "rgba(59, 130, 246, 0.1)";
                    el.style.color = "#3b82f6"; // Blue
                    el.style.borderColor = "rgba(59, 130, 246, 0.3)";
                } else if (plan === "PREMIUM") {
                    el.style.backgroundColor = "rgba(249, 115, 22, 0.1)";
                    el.style.color = "#f97316"; // Reddish-Orange
                    el.style.borderColor = "rgba(249, 115, 22, 0.3)";
                } else {
                    // Basic / Free (Simple)
                    el.style.backgroundColor = "rgba(255, 255, 255, 0.05)";
                    el.style.color = "#cbd5e1"; // Simple Light Grey
                    el.style.borderColor = "rgba(255, 255, 255, 0.1)";
                }
            }

            const pb = document.getElementById("planBadge");
            applyPlanStyle(pb, planType);

            // Credits & Plan (Autofill Tab)
            const autoRemEl = document.getElementById("autofillCreditsRemaining");
            if (autoRemEl) autoRemEl.textContent = remaining;
            const autoTotEl = document.getElementById("autofillCreditsTotal");
            if (autoTotEl) autoTotEl.textContent = total;
            const autoBadgeEl = document.getElementById("autofillPlanBadge");
            applyPlanStyle(autoBadgeEl, planType);

            // Upgrade logic for Autofill tab
            const autoUpgradeLink = document.getElementById("autofillUpgradeLink");
            if (autoUpgradeLink) {
                if (!isPremium) {
                    autoUpgradeLink.style.display = "block";
                    autoUpgradeLink.onclick = (e) => {
                        e.preventDefault();
                        chrome.tabs.create({ url: "https://app.vignova.io/dashboard/billing" });
                    };
                } else {
                    autoUpgradeLink.style.display = "none";
                }
            }

            // Run tab logic independent of each other so one failure doesn't freeze the whole UI
            loadProfileTab(data).catch(console.error);
            loadAutofillTab(data).catch(console.error);

        } catch (err) {
            console.error("[Vignova] Dashboard load error:", err);
        }
    }

    // ═══════════════════════════════════════════
    //  AUTOFILL TAB
    // ═══════════════════════════════════════════
    async function setAutofillProfileName(profile) {
        const profileNameEl = document.getElementById("agentProfileName");
        const selectEl = document.getElementById("agentProfileSelect");
        if (!profileNameEl) return;
        
        try {
            // Via service worker with the extension token — a direct cookie fetch
            // here would use the website's identity, which can be a different user
            const data = await chrome.runtime.sendMessage({ type: "API_GET_PROFILES" });

            if (data.success && data.profiles && data.profiles.length > 0) {
                if (data.profiles.length === 1 || !selectEl) {
                    profileNameEl.style.display = "inline";
                    if (selectEl) selectEl.style.display = "none";
                    profileNameEl.textContent = data.profiles[0].name;
                } else {
                    profileNameEl.style.display = "none";
                    selectEl.style.display = "inline-block";
                    selectEl.innerHTML = "";
                    data.profiles.forEach(p => {
                        const opt = document.createElement("option");
                        opt.value = p.id;
                        opt.textContent = p.name + (p.is_default ? " (Default)" : "");
                        if (p.is_default) opt.selected = true;
                        selectEl.appendChild(opt);
                    });

                    // Remove old listener if any, then add new
                    selectEl.onchange = async (e) => {
                        const newId = e.target.value;
                        selectEl.disabled = true;
                        try {
                            await chrome.runtime.sendMessage({
                                type: "API_SET_PROFILE",
                                data: { profileId: newId },
                            });

                            // Re-fetch all dashboard data to update all tabs (Profile, Keywords, Autofill)
                            await loadDashboard();
                        } catch(err) { console.error(err); }
                        selectEl.disabled = false;
                    };
                }
            } else {
                profileNameEl.style.display = "inline";
                if (selectEl) selectEl.style.display = "none";
                if (profile) {
                    profileNameEl.textContent = profile.first_name
                        ? `${profile.first_name} ${profile.last_name || ""}`.trim()
                        : "Master Profile";
                } else {
                    profileNameEl.textContent = "No Master Profile found";
                }
            }
        } catch (err) {
            // fallback
            profileNameEl.style.display = "inline";
            if (selectEl) selectEl.style.display = "none";
            if (profile) {
                profileNameEl.textContent = profile.first_name
                    ? `${profile.first_name} ${profile.last_name || ""}`.trim()
                    : "Master Profile";
            } else {
                profileNameEl.textContent = "No Master Profile found";
            }
        }
    }

    async function loadAutofillTab(statusData) {
        const profileNameEl = document.getElementById("agentProfileName");
        const startAgentBtn = document.getElementById("startAgentBtn");
        const agentBtnText = document.getElementById("agentBtnText");
        const agentBtnIcon = document.getElementById("agentBtnIcon");
        let agentRunning = false;

        if (statusData?.cached_profile) {
            cachedProfile = statusData.cached_profile;
        }
        await setAutofillProfileName(cachedProfile);

        // Refresh profile button
        document.getElementById("refreshProfileBtn")?.addEventListener("click", async () => {
            profileNameEl.textContent = "Refreshing...";
            const res = await chrome.runtime.sendMessage({ type: "API_AGENT_GET_PROFILE" });
            if (res?.success && res.profile) {
                profileNameEl.textContent = `${res.profile.first_name || ""} ${res.profile.last_name || ""}`.trim() || "Master Profile";
                cachedProfile = res.profile;
            }
        });

        // Default button state: disabled while scanning
        startAgentBtn.disabled = true;
        const originalBtnText = agentBtnText.textContent;
        agentBtnText.textContent = "Scanning for forms...";
        startAgentBtn.style.opacity = "0.7";

        // Detect job page fields via smart heuristics
        let hasFillableForm = false;
        let formCheckInterval = null;

        const checkFormPresence = async () => {
            if (agentRunning) return; // Stop checking if agent is running

            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab?.id) {
                    // Check if there are form elements on the page broadly, including all iframes
                    const injection = await chrome.scripting.executeScript({
                        target: { tabId: tab.id, allFrames: true },
                        func: () => {
                            // SMARTER HEURISTIC: Don't just count any 3 inputs across the web.
                            // 1. Check if we're on a known ATS / Job Board domain
                            const url = window.location.href.toLowerCase();
                            const isJobDomain = url.includes('greenhouse.io') ||
                                url.includes('lever.co') ||
                                url.includes('myworkdayjobs.com') ||
                                url.includes('workday.com') ||
                                url.includes('icims.com') ||
                                url.includes('smartrecruiters.com') ||
                                url.includes('ashbyhq.com') ||
                                url.includes('breezy.hr') ||
                                url.includes('applytojob.com') ||
                                url.includes('workable.com') ||
                                (url.includes('linkedin.com') && url.includes('jobs')) ||
                                (url.includes('indeed.com') && url.includes('jobs'));

                            // 2. Count "meaningful" fillable inputs
                            const inputs = document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]):not([type="search"]), textarea, select');
                            let validCount = 0;
                            let hasEmail = false;
                            let hasName = false;
                            let hasResumeUpload = document.querySelector('input[type="file"]') !== null;

                            for (let el of inputs) {
                                if (!el.disabled && !el.readOnly) {
                                    validCount++;
                                    const ident = (el.name + " " + el.id + " " + (el.placeholder || "")).toLowerCase();
                                    if (ident.includes("email")) hasEmail = true;
                                    if (ident.includes("name") || ident.includes("first") || ident.includes("last")) hasName = true;
                                }
                            }

                            // 3. Logic:
                            // If it's a known ATS/Job page and has at least 2 inputs -> YES
                            if (isJobDomain && validCount >= 2) return true;

                            // If it has a file upload (Resume) AND asks for basic info -> YES
                            if (hasResumeUpload && (hasEmail || hasName) && validCount >= 2) return true;

                            // If it explicitly asks for Name AND Email and has multiple inputs -> YES
                            if (hasEmail && hasName && validCount >= 3) return true;

                            // If it's a massive form (e.g. >= 8 fields) we assume it's fillable -> YES
                            if (validCount >= 8) return true;

                            return false;
                        }
                    });

                    // If any frame has a form, we consider it fillable
                    hasFillableForm = injection?.some(frame => frame.result === true) || false;

                    // Also check if the agent is ALREADY running
                    await new Promise((resolve) => {
                        chrome.tabs.sendMessage(tab.id, { type: "GET_AGENT_STATE" }, (response) => {
                            if (!chrome.runtime.lastError && response?.isRunning) {
                                agentRunning = true;
                            }
                            resolve();
                        });
                    });

                    updateButtonState();
                }
            } catch (e) { /* ignore */ }
        };

        const updateButtonState = () => {
            startAgentBtn.style.opacity = "1";
            if (agentRunning) {
                startAgentBtn.disabled = false;
                agentBtnText.textContent = "⏹ Stop Auto Fill";
                startAgentBtn.classList.add("vignova-btn-autofill-active");
                agentBtnIcon.innerHTML = "";
            } else if (hasFillableForm) {
                startAgentBtn.disabled = false;
                agentBtnText.textContent = originalBtnText || "Autofill this page";
                agentBtnIcon.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>`;
            } else {
                startAgentBtn.disabled = true;
                agentBtnText.textContent = "No forms found";
                agentBtnIcon.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;
            }
        };

        // Initial check and start polling
        checkFormPresence();
        formCheckInterval = setInterval(checkFormPresence, 1500);

        // Start/Stop Agent
        startAgentBtn.addEventListener("click", async () => {
            if (!agentRunning && !isPremium) {
                showUpgradeModal("Auto Fill Agent");
                return;
            }
            if (agentRunning) {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (tab?.id) {
                    chrome.tabs.sendMessage(tab.id, { type: "STOP_AGENT" });
                }
                agentRunning = false;
                agentBtnText.textContent = "Autofill this page";
                agentBtnIcon.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>`;
                startAgentBtn.classList.remove("vignova-btn-autofill-active");
            } else {
                startAgentBtn.disabled = true;
                agentBtnText.textContent = "Starting...";

                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (!tab?.id) {
                    agentBtnText.textContent = "Autofill this page";
                    startAgentBtn.disabled = false;
                    return;
                }

                const result = await chrome.runtime.sendMessage({
                    type: "START_AGENT_ON_TAB",
                    tabId: tab.id,
                });

                startAgentBtn.disabled = false;
                if (result?.success) {
                    agentRunning = true;
                    agentBtnText.textContent = "⏹ Stop Auto Fill";
                    agentBtnIcon.textContent = "";
                    startAgentBtn.classList.add("vignova-btn-autofill-active");
                } else {
                    agentBtnText.textContent = "Autofill this page";
                    alert("Could not start agent: " + (result?.error || "Make sure you're on a job application page."));
                }
            }
        });

        // ─── Quick Actions ───

        // Save Job
        document.getElementById("saveJobBtn")?.addEventListener("click", async () => {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab?.id) return;

            try {
                showToast("Saving job...");
                const jobData = await extractJobData(tab);

                const res = await chrome.runtime.sendMessage({
                    type: "API_SAVE_JOB",
                    data: {
                        jobTitle: jobData.title,
                        company: jobData.company,
                        jobUrl: tab.url,
                        location: jobData.location,
                        description: jobData.description,
                        source: "extension",
                    },
                });

                showToast(res?.success ? "Job saved! ✓" : (res?.error || "Failed to save"));
            } catch (e) {
                showToast("Error saving job");
            }
        });

        // Tailor Resume — Phase 1: extract JD and show review screen
        document.getElementById("tailorResumeBtn")?.addEventListener("click", async () => {
            if (!isPremium) {
                showUpgradeModal("Tailor Resume");
                return;
            }
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab?.id) return;

            showToast("Reading job page...");
            try {
                const jobData = await extractJobData(tab);

                // Populate the JD review screen
                document.getElementById("jdReviewJobTitle").textContent = jobData.title || "Unknown Job";
                document.getElementById("jdReviewCompany").textContent = jobData.company || tab.url;

                const textarea = document.getElementById("jdReviewTextarea");
                textarea.value = jobData.description || "";
                const charCount = document.getElementById("jdReviewCharCount");
                charCount.textContent = `${textarea.value.length.toLocaleString()} chars`;

                textarea.addEventListener("input", () => {
                    charCount.textContent = `${textarea.value.length.toLocaleString()} chars`;
                }, { once: false });

                // Back / Cancel buttons → return to dashboard
                document.getElementById("jdReviewBackBtn").onclick = () => showView(dashboardView);
                document.getElementById("jdReviewCancelBtn").onclick = () => showView(dashboardView);

                // Generate button — Phase 2: inject overlay and trigger generation
                const genBtn = document.getElementById("jdReviewGenerateBtn");
                const genBtnText = document.getElementById("jdReviewGenBtnText");
                const genSpinner = document.getElementById("jdReviewGenSpinner");

                genBtn.onclick = async () => {
                    const confirmedJD = textarea.value.trim();
                    if (!confirmedJD) {
                        showToast("Please enter a job description.");
                        return;
                    }
                    const hint = document.getElementById("jdReviewHintInput")?.value.trim() || "";

                    genBtn.disabled = true;
                    genBtnText.style.display = "none";
                    genSpinner.style.display = "inline-block";

                    try {
                        await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content/overlay.css"] }).catch(() => {});
                        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content/overlay.js"] }).catch(() => {});

                        chrome.scripting.executeScript({
                            target: { tabId: tab.id },
                            func: (data) => {
                                if (typeof Vignova_Overlay !== "undefined") {
                                    Vignova_Overlay.showLoading();
                                    chrome.runtime.sendMessage({ type: "API_GENERATE_RESUME", data }, (response) => {
                                        if (response?.success) {
                                            Vignova_Overlay.showSuccess(response.pdfBase64, "Vignova_Tailored_Resume.pdf", response.credits_remaining);
                                        } else {
                                            Vignova_Overlay.showError(response?.error || "Failed to generate resume.", () => Vignova_Overlay.remove());
                                        }
                                    });
                                } else {
                                    alert("Overlay failed to load. Please refresh the page.");
                                }
                            },
                            args: [{
                                jobTitle: jobData.title,
                                company: jobData.company,
                                jobUrl: tab.url,
                                jobDescription: confirmedJD,
                                hint: hint || undefined,
                                source: "extension"
                            }]
                        });

                        window.close(); // Close popup — user watches generation on the page
                    } catch (err) {
                        console.error(err);
                        genBtn.disabled = false;
                        genBtnText.style.display = "inline";
                        genSpinner.style.display = "none";
                        showToast("Failed to start generation.");
                    }
                };

                showView(jdReviewView);
            } catch (err) {
                console.error(err);
                showToast("Failed to read job details.");
            }
        });

        // Cover Letter
        document.getElementById("coverLetterBtn")?.addEventListener("click", async () => {
            if (!isPremium) {
                showUpgradeModal("Cover Letter Generator");
                return;
            }
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab?.id) return;

            try {
                showToast("Generating cover letter...");
                const jobData = await extractJobData(tab);

                const res = await chrome.runtime.sendMessage({
                    type: "API_GENERATE_COVER_LETTER",
                    data: {
                        jobTitle: jobData.title,
                        company: jobData.company,
                        jobUrl: tab.url,
                        description: jobData.description,
                    },
                });

                if (res?.success) {
                    showToast("Cover letter saved! ✓");
                    chrome.tabs.create({ url: `https://app.vignova.io/dashboard/jobs` });
                } else {
                    showToast(res?.error || "Failed to generate");
                }
            } catch (e) {
                showToast("Error: " + (e.message || "Unknown"));
            }
        });

        // Interview Prep (PREMIUM)
        document.getElementById("interviewPrepBtn")?.addEventListener("click", async () => {
            if (!isPremium) {
                showUpgradeModal("Interview Prep");
                return;
            }
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab?.id) return;

            try {
                const jobData = await extractJobData(tab);

                document.getElementById("ipJobTitle").textContent = jobData.title || "Interview Prep";
                document.getElementById("ipJobCompany").textContent = jobData.company || "AI-powered questions";

                document.getElementById("ipLoadingState").style.display = "block";
                document.getElementById("ipResultState").style.display = "none";
                document.getElementById("ipErrorState").style.display = "none";

                document.getElementById("interviewPrepBackBtn").onclick = () => showView(dashboardView);
                showView(interviewPrepView);

                // Generate locally — no API needed
                const { vignova_agent_profile: profile } = await chrome.storage.local.get(['vignova_agent_profile']);
                const questions = (typeof VignovaInterviewPrep !== "undefined")
                    ? VignovaInterviewPrep.generate(jobData.title, jobData.company, jobData.description, profile || null)
                    : [];

                document.getElementById("ipLoadingState").style.display = "none";

                if (questions.length > 0) {
                    const list = document.getElementById("ipQuestionsList");
                    list.innerHTML = questions.map((q, i) => `
                        <div class="vignova-ip-question">
                            <div class="vignova-ip-question-num">Q${i + 1}</div>
                            <div class="vignova-ip-question-text">${escapeHtml(q.question)}</div>
                            ${q.tip ? `<div class="vignova-ip-question-tip">💡 ${escapeHtml(q.tip)}</div>` : ""}
                        </div>
                    `).join("");
                    // MV3 CSP forbids inline event handlers — bind via JS instead
                    list.querySelectorAll(".vignova-ip-question").forEach((el) => {
                        el.addEventListener("click", () => el.classList.toggle("expanded"));
                    });
                    document.getElementById("ipResultState").style.display = "block";
                } else {
                    document.getElementById("ipErrorMsg").textContent = "Could not generate questions. Make sure a job is open.";
                    document.getElementById("ipErrorState").style.display = "block";
                }
                document.getElementById("ipRetryBtn").onclick = () => document.getElementById("interviewPrepBtn").click();
                document.getElementById("ipErrorBackBtn").onclick = () => showView(dashboardView);
            } catch (e) {
                document.getElementById("ipLoadingState").style.display = "none";
                document.getElementById("ipErrorMsg").textContent = "Could not load job details. Please try again.";
                document.getElementById("ipErrorState").style.display = "block";
                document.getElementById("ipErrorBackBtn").onclick = () => showView(dashboardView);
            }
        });

        // Job Tracker Link
        document.getElementById("jobTrackerLink")?.addEventListener("click", (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: "https://app.vignova.io/dashboard/jobs" });
        });

        // Fetch Recent Jobs
        const recentJobsList = document.getElementById("recentJobsList");
        if (recentJobsList) {
            try {
                const jobsRes = await chrome.runtime.sendMessage({ type: "API_GET_RECENT_JOBS" });
                if (jobsRes?.success && jobsRes.jobs?.length > 0) {
                    // MV3 CSP forbids inline event handlers — hover styles live in popup.css
                    recentJobsList.innerHTML = jobsRes.jobs.map(job => `
                        <div class="vignova-recent-job">
                            <div class="vignova-recent-job-main">
                                <div class="vignova-recent-job-title">${escapeHtml(job.jobTitle || "")}</div>
                                <div class="vignova-recent-job-company">
                                    <span style="display: flex; align-items: center;"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect><path d="M9 22v-4h6v4"></path><path d="M8 6h.01"></path><path d="M16 6h.01"></path><path d="M12 6h.01"></path><path d="M12 10h.01"></path><path d="M12 14h.01"></path><path d="M16 10h.01"></path><path d="M16 14h.01"></path><path d="M8 10h.01"></path><path d="M8 14h.01"></path></svg></span> ${escapeHtml(job.company || "")}
                                </div>
                            </div>
                            <a href="https://app.vignova.io/dashboard/jobs" target="_blank" class="vignova-recent-job-link" title="Open Job Tracker">›</a>
                        </div>
                    `).join('');
                } else {
                    recentJobsList.innerHTML = `<div style="font-size: 12px; color: #9ca3af; text-align: center; padding: 16px 0; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">No jobs tracked yet.</div>`;
                }
            } catch (err) {
                recentJobsList.innerHTML = `<div style="font-size: 12px; color: #ef4444; text-align: center; padding: 12px 0;">Failed to load jobs.</div>`;
            }
        }
    }

    // ═══════════════════════════════════════════
    //  KEYWORDS TAB
    // ═══════════════════════════════════════════
    let hasAnalyzedKeywords = false;

    async function runKeywordAnalysis() {
        if (hasAnalyzedKeywords) return; // Prevent re-running if already done

        const emptyState = document.getElementById("keywordEmptyState");
        const resultState = document.getElementById("keywordResultState");
        const statusText = document.getElementById("scoreStatus");

        if (!emptyState || !resultState || !statusText) return;

        // Reset UI to analyzing state
        emptyState.style.display = "block";
        resultState.style.display = "none";
        statusText.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; gap:8px;">
                <span class="vignova-spinner" style="border-top-color:#2563eb; width:20px; height:20px;"></span>
                <span>Analyzing job description...</span>
            </div>
        `;

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (!tab?.id) throw new Error("No active tab");

            // Extract JD from the page
            // Extract all text from the page up to 1500 words
            const jdResult = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                    const allText = document.body.innerText || "";
                    // Split by whitespace to get words, take up to 1500, then join back
                    const words = allText.trim().split(/\s+/);
                    return words.slice(0, 1500).join(" ");
                },
            });

            const jdText = jdResult?.[0]?.result || "";
            if (jdText.length < 50) {
                throw new Error("Could not extract job description from this page");
            }

            // Call ATS score API
            const response = await chrome.runtime.sendMessage({
                type: "API_GET_SCORE",
                data: { jobDescription: jdText },
            });

            if (response?.success) {
                renderKeywordResults(response);
            } else {
                throw new Error(response?.error || "Score analysis failed");
            }
            // Show Results
            emptyState.style.display = "none";
            resultState.style.display = "block";
            hasAnalyzedKeywords = true;

        } catch (error) {
            console.error(error);
            emptyState.style.display = "block";
            resultState.style.display = "none";
            statusText.innerHTML = `<span style="color:#ef4444;">${error.message || "Failed to analyze keywords."}</span>`;
        }
    }

    function renderKeywordResults(data) {
        document.getElementById("keywordEmptyState").style.display = "none";

        const score = data.score ?? data.ats_score ?? 0;
        const matched = data.breakdown?.matching_keywords || data.matched_keywords || data.matched || [];
        const missing = data.breakdown?.missing_keywords || data.missing_keywords || data.missing || [];

        // Calculate proxy metrics since python API only returns total score & keywords
        let semScore = Math.min(100, Math.round(score * 1.05 + 5));
        let kwScore = Math.min(100, Math.round(score * 0.95 - 5));

        document.getElementById("keywordResultState").style.display = "block";
        document.getElementById("mbScore").textContent = score;

        document.getElementById("mbSemBar").style.width = `${semScore}%`;
        document.getElementById("mbSemVal").textContent = `${semScore}%`;

        document.getElementById("mbKwBar").style.width = `${kwScore}%`;
        document.getElementById("mbKwVal").textContent = `${kwScore}%`;

        // Combine and split into mock High/Low priority lists for the UI
        const allKws = [
            ...matched.map((k) => ({ text: k, matched: true })),
            ...missing.map((k) => ({ text: k, matched: false }))
        ];

        // Sort by length to give a realistic look (longer words often more specific/lower priority)
        allKws.sort((a, b) => a.text.length - b.text.length);

        const cutoff = Math.min(15, Math.ceil(allKws.length * 0.6));
        const highPriority = allKws.slice(0, cutoff);
        // Limit low priority to keep UI clean
        const lowPriority = allKws.slice(cutoff, cutoff + 10);

        function renderTier(listId, countId, items) {
            const container = document.getElementById(listId);
            const countEl = document.getElementById(countId);
            if (!container || !countEl) return;

            const matchedCount = items.filter(i => i.matched).length;
            countEl.textContent = `${matchedCount}/${items.length}`;

            container.innerHTML = items.map(item => `
                <div class="vignova-keyword-item">
                    <div class="vignova-keyword-icon ${item.matched ? 'matched' : 'missing'}">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                    </div>
                    <span>${item.text}</span>
                </div>
            `).join("");
        }

        renderTier("highPriorityList", "hpCount", highPriority);
        renderTier("lowPriorityList", "lpCount", lowPriority);

        // Profile improvement tip — show if there are missing keywords
        const existingTip = document.getElementById("kwProfileTip");
        if (existingTip) existingTip.remove();

        if (missing.length > 0) {
            const tipEl = document.createElement("a");
            tipEl.id = "kwProfileTip";
            tipEl.href = "#";
            tipEl.className = "vignova-profile-tip";
            tipEl.innerHTML = `
                <span class="vignova-profile-tip-text">
                    <strong>${missing.length} skill${missing.length > 1 ? "s" : ""} missing from your profile</strong> — add them to boost your score
                </span>
                <span class="vignova-profile-tip-arrow">→</span>
            `;
            tipEl.addEventListener("click", (e) => {
                e.preventDefault();
                chrome.tabs.create({ url: "https://app.vignova.io/dashboard/profile" });
            });
            document.getElementById("keywordResultState")?.appendChild(tipEl);
        }
    }

    // ═══════════════════════════════════════════
    //  PROFILE TAB
    // ═══════════════════════════════════════════
    async function loadProfileTab(statusData) {
        try {
            if (statusData?.cached_profile) {
                cachedProfile = statusData.cached_profile;
            }

            if (!cachedProfile) return;

            const p = cachedProfile;

            // Avatar
            const initials = ((p.first_name || "")[0] || "") + ((p.last_name || "")[0] || "");
            document.getElementById("profileAvatar").textContent = initials.toUpperCase() || "?";

            // Name & Location
            document.getElementById("profileName").textContent =
                `${p.first_name || ""} ${p.last_name || ""}`.trim() || "User";
            document.getElementById("profileLocation").textContent =
                [p.city, p.country].filter(Boolean).join(", ") || "—";

            // Contact rows (click to copy)
            const contactRows = document.getElementById("contactRows");
            const contacts = [
                { icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>', text: p.email, label: "Email" },
                { icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>', text: p.phone, label: "Phone" },
                { icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>', text: p.linkedin, label: "LinkedIn" },
                { icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>', text: p.github, label: "GitHub" },
                { icon: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>', text: p.portfolio, label: "Portfolio" },
            ].filter((c) => c.text);

            contactRows.innerHTML = contacts
                .map(
                    (c) => `
                <div class="vignova-copy-row" data-copy="${escapeHtml(c.text)}">
                    <span class="vignova-copy-row-icon">${c.icon}</span>
                    <span class="vignova-copy-row-text">${escapeHtml(c.text)}</span>
                    <span class="vignova-copy-row-hint">Click to copy</span>
                </div>`
                )
                .join("");

            // Add click-to-copy handlers
            contactRows.querySelectorAll(".vignova-copy-row").forEach((row) => {
                row.addEventListener("click", () => {
                    copyText(row.dataset.copy);
                    showToast("Copied!");
                });
            });

            // Education
            const eduList = document.getElementById("educationList");
            const education = p.education || [];
            if (education.length > 0) {
                eduList.innerHTML = education
                    .map(
                        (e) => `
                    <div class="vignova-exp-item" data-copy="${escapeHtml(e.degree || "")} in ${escapeHtml(e.field || "")} - ${escapeHtml(e.school || "")}">
                        <div class="vignova-exp-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"></path><path d="M6 12v5c3 3 9 3 12 0v-5"></path></svg></div>
                        <div>
                            <div class="vignova-exp-title">${escapeHtml(e.school || "Unknown")}</div>
                            <div class="vignova-exp-sub">${escapeHtml(e.degree || "")}${e.field ? " in " + escapeHtml(e.field) : ""}</div>
                            <div class="vignova-exp-dates">${escapeHtml(e.dates || e.start_date || "")}${e.end_date ? " - " + escapeHtml(e.end_date) : ""}</div>
                            ${e.grade ? `<div style="font-size:11px; color:#555; margin-top:2px;">Grade/GPA: ${escapeHtml(e.grade)}</div>` : ""}
                        </div>
                    </div>`
                    )
                    .join("");
            }

            // Experience
            const expList = document.getElementById("experienceList");
            const experience = p.experience || [];
            if (experience.length > 0) {
                expList.innerHTML = experience
                    .slice(0, 4)
                    .map(
                        (e) => `
                    <div class="vignova-exp-item" data-copy="${escapeHtml(e.title || "")} at ${escapeHtml(e.company || "")}\n${escapeHtml(e.description || "")}">
                        <div class="vignova-exp-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg></div>
                        <div>
                            <div class="vignova-exp-title">${escapeHtml(e.title || "Unknown")}</div>
                            <div class="vignova-exp-sub">${escapeHtml(e.company || "")}${e.location ? " • " + escapeHtml(e.location) : ""}</div>
                            <div class="vignova-exp-dates">${escapeHtml(e.dates || e.start_date || "")}${e.end_date ? " - " + escapeHtml(e.end_date) : ""}</div>
                            ${e.description ? `<div style="font-size:11px; color:#555; margin-top:4px; line-height:1.4;">${escapeHtml(e.description)}</div>` : ""}
                        </div>
                    </div>`
                    )
                    .join("");
            }

            // Summary
            const summary = p.summary || "";
            if (summary) {
                document.getElementById("summarySection").style.display = "block";
                const summaryText = document.getElementById("summaryText");
                summaryText.innerHTML = `<div class="vignova-copyable-block" data-copy="${escapeHtml(summary)}" title="Click to copy">${escapeHtml(summary)}</div>`;

                // Make copyable
                summaryText.querySelector('.vignova-copyable-block').addEventListener("click", function () {
                    copyText(this.dataset.copy);
                    showToast("Copied!");
                });
            }

            // Skills
            const skills = p.skills || [];
            if (skills.length > 0) {
                document.getElementById("skillsSection").style.display = "block";
                const skillsGrid = document.getElementById("skillsChips");
                skillsGrid.innerHTML = skills
                    .map((s) => `<span class="vignova-chip vignova-chip-match" data-copy="${escapeHtml(s)}" style="cursor:pointer;" title="Click to copy">${escapeHtml(s)}</span>`)
                    .join("");

                // Make skills copyable
                skillsGrid.querySelectorAll('.vignova-chip').forEach(chip => {
                    chip.addEventListener("click", function () {
                        copyText(this.dataset.copy);
                        showToast("Copied!");
                    });
                });
            }

            // Projects
            const projList = document.getElementById("projectsList");
            const projects = p.projects || [];
            if (projects.length > 0) {
                projList.innerHTML = projects
                    .map(
                        (pr) => `
                    <div class="vignova-exp-item" data-copy="${escapeHtml(pr.name || "")} - ${escapeHtml(pr.tech_stack || "")}\n${escapeHtml(pr.description || "")}">
                        <div class="vignova-exp-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg></div>
                        <div style="flex:1;">
                            <div class="vignova-exp-title" style="display:flex; justify-content:space-between; align-items:flex-start;">
                                <span style="color:#111; font-size:13px;">${escapeHtml(pr.name || "Unknown")}</span>
                                ${pr.link ? `<a href="${escapeHtml(pr.link)}" target="_blank" style="font-size:10px; color:#0ea5e9; text-decoration:none; padding:2px 6px; background:rgba(14,165,233,0.1); border-radius:4px; font-weight:600;">Link ↗</a>` : ""}
                            </div>
                            <div class="vignova-exp-sub" style="color:#22c55e; font-weight:600; font-size:11px; margin-top:4px;">${escapeHtml(pr.tech_stack || "")}</div>
                            ${pr.description ? `<div style="font-size:11px; color:#555; margin-top:6px; line-height:1.5; background:rgba(0,0,0,0.02); padding:8px 10px; border-radius:6px; border:1px solid rgba(0,0,0,0.04);">${escapeHtml(pr.description)}</div>` : ""}
                        </div>
                    </div>`
                    )
                    .join("");
            }

            // Certifications
            const certList = document.getElementById("certificationsList");
            const certifications = p.certifications || [];
            if (certifications.length > 0) {
                certList.innerHTML = certifications
                    .map(
                        (c) => `
                    <div class="vignova-exp-item" data-copy="${escapeHtml(c.name || "")} (${escapeHtml(c.issuer || "")})">
                        <div class="vignova-exp-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="7"></circle><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline></svg></div>
                        <div style="flex:1;">
                            <div class="vignova-exp-title" style="color:#111; font-size:12px;">${escapeHtml(c.name || "Unknown")}</div>
                            <div class="vignova-exp-sub" style="color:#0ea5e9; font-weight:600; font-size:11px; margin-top:2px;">${escapeHtml(c.issuer || "")}</div>
                            <div class="vignova-exp-dates" style="margin-top:2px;">${escapeHtml(c.date || "")}</div>
                        </div>
                    </div>`
                    )
                    .join("");
            }

            // Languages
            const langList = document.getElementById("languagesList");
            const languages = p.languages || [];
            if (languages.length > 0) {
                document.getElementById("languagesSection").style.display = "block";
                langList.innerHTML = languages
                    .map(
                        (l) => `<div class="vignova-copyable-block vignova-lang-item" data-copy="${escapeHtml(l.name || "")} - ${escapeHtml(l.proficiency || "")}" style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 6px;" title="Click to copy">
                            <span style="font-weight: 600; color: #333; font-size:12px;">${escapeHtml(l.name || "Unknown")}</span>
                            <span style="color: #0ea5e9; font-size: 11px; font-weight:600; background: rgba(14,165,233,0.1); padding: 2px 8px; border-radius: 10px;">${escapeHtml(l.proficiency || "")}</span>
                        </div>`
                    )
                    .join("");

                // Make languages copyable
                langList.querySelectorAll('.vignova-lang-item').forEach(item => {
                    item.addEventListener("click", function () {
                        try {
                            navigator.clipboard.writeText(this.dataset.copy);
                        } catch (e) {
                            const ta = document.createElement('textarea');
                            ta.value = this.dataset.copy;
                            document.body.appendChild(ta);
                            ta.select();
                            document.execCommand('copy');
                            document.body.removeChild(ta);
                        }
                        showToast("Copied!");
                    });
                });
            }

            // Make all exp/edu/proj/cert items copyable
            document.querySelectorAll(".vignova-exp-item").forEach((item) => {
                item.addEventListener("click", () => {
                    const text = item.dataset.copy || item.innerText;
                    try {
                        navigator.clipboard.writeText(text);
                    } catch (e) {
                        const ta = document.createElement('textarea');
                        ta.value = text;
                        document.body.appendChild(ta);
                        ta.select();
                        document.execCommand('copy');
                        document.body.removeChild(ta);
                    }
                    showToast("Copied!");
                });
            });

            // Edit link
            document.getElementById("editProfileLink")?.addEventListener("click", (e) => {
                e.preventDefault();
                chrome.tabs.create({ url: "https://app.vignova.io/dashboard/profile" });
            });

        } catch (err) {
            console.error("[Vignova] Profile tab error:", err);
        }
    }

    // ═══════════════════════════════════════════
    //  HELPERS
    // ═══════════════════════════════════════════

    /**
     * Extract job data (title, company, location, description) from the active tab.
     * Works across major job sites via smart DOM selectors.
     */
    async function extractJobData(tab) {
        try {
            const result = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                    // Start by looking for the specific split-pane detail view to avoid grabbing sidebar lists
                    let base = document.querySelector(
                        '#jobsearch-ViewjobPaneWrapper, .jobsearch-JobComponent, .jobsearch-RightPane, .jobs-search__job-details--container, .jobs-details__main-content, .job-view-layout'
                    ) || document;

                    const $ = (sel) => base.querySelector(sel) || document.querySelector(sel);
                    const text = (sel) => {
                        const el = $(sel);
                        return el ? el.innerText.trim() : "";
                    };

                    // Title
                    let title = text('h1[class*="title"], h1[class*="job-title"], h1.app-title')
                        || text('h1.posting-headline, h1.job-title')
                        || text('h1')
                        || document.querySelector('meta[property="og:title"]')?.content
                        || document.title;

                    // Company
                    let company = text('[class*="company-name"], [class*="CompanyName"]')
                        || text('.posting-categories .sort-by-team, [class*="employer"]')
                        || text('[data-company], [class*="company"]')
                        || document.querySelector('meta[property="og:site_name"]')?.content
                        || "";

                    // Clean title - many sites put "Job Title - Company" in <title>
                    if (!company && title.includes(" - ")) {
                        const parts = title.split(" - ");
                        if (parts.length >= 2) {
                            company = parts[parts.length - 1].trim();
                            title = parts.slice(0, -1).join(" - ").trim();
                        }
                    }
                    if (!company && title.includes(" at ")) {
                        const parts = title.split(" at ");
                        company = parts[parts.length - 1].trim();
                        title = parts.slice(0, -1).join(" at ").trim();
                    }

                    // Location
                    let location = text('[class*="location"], [class*="Location"]')
                        || text('.posting-categories .sort-by-location')
                        || "";

                    // Description
                    let description = "";
                    const descSelectors = [
                        '[class*="description"], [class*="Description"]',
                        '[class*="job-description"]',
                        '#job-description, #content',
                        '#job-detail-panel', // Greenhouse ATS
                        '.posting-page',
                        'article',
                        'main',
                    ];
                    for (const sel of descSelectors) {
                        const el = base.querySelector(sel) || document.querySelector(sel);
                        if (el && el.innerText.length > 100) {
                            description = el.innerText;
                            break;
                        }
                    }
                    if (!description) {
                        description = base.innerText || document.body.innerText || "";
                    }

                    // Limit job description to roughly 1500 words to ensure it captures the full meaningful post
                    const words = description.trim().split(/\s+/);
                    description = words.slice(0, 1500).join(" ");

                    // Strict cleaner to prevent garbage Cookie Accept texts from blowing up the UI
                    const cleanString = (str, maxLen) => {
                        if (!str) return "";
                        let cleaned = str.replace(/\n+/g, " ").replace(/\s+/g, " ").trim();
                        // If there are words longer than 30 chars with no spaces (e.g. encoded HTML or CSS class dumps), truncate them
                        cleaned = cleaned.split(" ").map(w => w.length > 30 ? w.substring(0, 30) + "..." : w).join(" ");
                        return cleaned.length > maxLen ? cleaned.substring(0, maxLen) + "..." : cleaned;
                    };

                    title = cleanString(title, 150);
                    company = cleanString(company, 80);

                    return { title, company, location, description };
                },
            });

            return result?.[0]?.result || {
                title: tab.title || "Untitled",
                company: "",
                location: "",
                description: "",
            };
        } catch (err) {
            console.error("[Vignova] extractJobData error:", err);
            // Fallback to tab info
            let title = tab.title || "Untitled";
            let company = "";
            if (title.includes(" - ")) {
                const parts = title.split(" - ");
                company = parts[parts.length - 1];
                title = parts.slice(0, -1).join(" - ");
            }

            // Clean fallbacks
            const cleanString = (str, maxLen) => {
                if (!str) return "";
                let cleaned = str.replace(/\n+/g, " ").replace(/\s+/g, " ").trim();
                return cleaned.length > maxLen ? cleaned.substring(0, maxLen) + "..." : cleaned;
            };

            return {
                title: cleanString(title, 150),
                company: cleanString(company, 80),
                location: "",
                description: ""
            };
        }
    }

    function showToast(message) {
        copyToast.textContent = message;
        copyToast.classList.add("show");
        setTimeout(() => copyToast.classList.remove("show"), 1800);
    }

    function escapeHtml(text) {
        if (!text) return "";
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
    }

    // ═══════════════════════════════════════════
    //  DASHBOARD DRAG & CLOSE (Cross-Frame)
    // ═══════════════════════════════════════════
    const urlParams = new URLSearchParams(window.location.search);
    const isDashboardMode = urlParams.get("mode") === "dashboard" || window.self !== window.top;

    const header = document.querySelector(".vignova-header");
    const closeBtn = document.getElementById("closeBtn");

    if (isDashboardMode) {
        // We are in an iframe injected on the page
        if (header) {
            header.style.cursor = "default";
        }

        if (closeBtn) {
            closeBtn.style.display = "block"; // Ensure visible
            closeBtn.addEventListener("click", () => {
                window.parent.postMessage({ type: "Vignova_CLOSE_DASHBOARD" }, "*");
            });
        }
    } else {
        // Standard dropdown popup – hide close button
        if (closeBtn) closeBtn.style.display = "none";
    }

    // Also: Listen for cross-frame AGENT_STATUS messages from the parent window's pub-sub 
    // to dynamically update the UI in case it's triggered externally
    window.addEventListener("message", (e) => {
        if (e.data && e.data.type === "Vignova_AGENT_STATUS") {
            const agentBtnText = document.getElementById("agentBtnText");
            const startAgentBtn = document.getElementById("startAgentBtn");
            const agentBtnIcon = document.getElementById("agentBtnIcon");
            const statusText = document.getElementById("agentStatusText");

            // Update live status line
            if (statusText) {
                if (e.data.status === "stopped" || e.data.status === "done" || e.data.status === "error" || e.data.status === "waiting_for_form") {
                    statusText.style.display = "none";
                } else {
                    statusText.style.display = "block";

                    if (e.data.status === "started") statusText.textContent = "Initializing Auto Fill...";
                    else if (e.data.status === "observing") statusText.textContent = "Scanning page for forms...";
                    else if (e.data.status === "planning") statusText.textContent = "Matching profile to fields...";
                    else if (e.data.status === "filling" || e.data.status === "ai_filling") {
                        statusText.textContent = `Filling: ${e.data.fieldsText || (e.data.count + " fields")}...`;
                    }
                    else if (e.data.status === "filled" || e.data.status === "ai_filled") {
                        statusText.textContent = `Filled ${e.data.success?.length || 0} fields ✓`;
                    }
                    else {
                        statusText.textContent = e.data.text || "Working...";
                        if (e.data.progress) {
                            statusText.textContent += ` (${e.data.progress})`;
                        }
                    }
                }
            }

            if (e.data.status === "stopped" || e.data.status === "done" || e.data.status === "error") {
                agentBtnText.textContent = "Autofill this page";
                agentBtnIcon.textContent = "⚡";
                startAgentBtn.classList.remove("vignova-btn-autofill-active");
            } else {
                agentBtnText.textContent = "⏹ Stop Auto Fill";
                agentBtnIcon.textContent = "";
                startAgentBtn.classList.add("vignova-btn-autofill-active");
            }
        }
    });
});
