/**
 * Vignova Extension — Overlay Manager
 * Manages the result/loading overlay shown on LinkedIn/Indeed.
 * Must be loaded BEFORE linkedin.js / indeed.js
 */

// ── JD Review Panel ────────────────────────────────────────────────────
// Shows an inline editable panel so the user can verify and correct the
// scraped job description before generation starts.
const Vignova_JDReview = {
    _panel: null,
    _highlightedEl: null,

    /**
     * @param {object} jobData         - scraped job data (jobDescription, jobTitle…)
     * @param {Element|null} descriptionEl - the DOM element that was scraped
     * @param {Element} anchorContainer  - the injected button bar (panel inserts after it)
     * @param {function} onConfirm      - called with the (possibly edited) JD string
     * @param {function} onCancel       - called when the user dismisses the panel
     */
    show(jobData, descriptionEl, anchorContainer, onConfirm, onCancel) {
        this.hide();

        // Highlight the source element so the user can see what was scraped
        if (descriptionEl) {
            this._highlightedEl = descriptionEl;
            descriptionEl.classList.add('vignova-jd-highlight');
            descriptionEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // Build panel
        this._panel = document.createElement('div');
        this._panel.className = 'vignova-jdr-panel';
        this._panel.innerHTML = `
            <div class="vignova-jdr-header">
                <div class="vignova-jdr-header-left">
                    <span class="vignova-jdr-dot"></span>
                    <div>
                        <div class="vignova-jdr-title">Confirm Job Description</div>
                        <div class="vignova-jdr-subtitle">Highlighted below · Edit anything that's missing before generating</div>
                    </div>
                </div>
                <button class="vignova-jdr-cancel-x" id="vignova-jdr-cancel-x" title="Cancel">✕</button>
            </div>
            <textarea class="vignova-jdr-textarea" id="vignova-jdr-textarea" placeholder="Job description…" spellcheck="false"></textarea>
            <div class="vignova-jdr-footer">
                <span class="vignova-jdr-char-count" id="vignova-jdr-char-count">0 chars</span>
                <div class="vignova-jdr-actions">
                    <button class="vignova-jdr-btn-cancel" id="vignova-jdr-btn-cancel">Cancel</button>
                    <button class="vignova-jdr-btn-generate" id="vignova-jdr-btn-generate">⚡ Generate Resume</button>
                </div>
            </div>
        `;

        // Set textarea value safely (no innerHTML injection)
        const textarea = this._panel.querySelector('#vignova-jdr-textarea');
        textarea.value = jobData.jobDescription || '';

        // Char count
        const charCount = this._panel.querySelector('#vignova-jdr-char-count');
        charCount.textContent = `${textarea.value.length.toLocaleString()} chars`;
        textarea.addEventListener('input', () => {
            charCount.textContent = `${textarea.value.length.toLocaleString()} chars`;
        });

        // Insert right after the anchor container so it flows below the button bar
        if (anchorContainer && anchorContainer.parentNode) {
            anchorContainer.parentNode.insertBefore(this._panel, anchorContainer.nextSibling);
        } else {
            document.body.appendChild(this._panel);
        }

        // Cancel
        const cancelFn = () => { this.hide(); if (onCancel) onCancel(); };
        this._panel.querySelector('#vignova-jdr-cancel-x').addEventListener('click', cancelFn);
        this._panel.querySelector('#vignova-jdr-btn-cancel').addEventListener('click', cancelFn);

        // Confirm
        this._panel.querySelector('#vignova-jdr-btn-generate').addEventListener('click', () => {
            const confirmed = textarea.value.trim();
            this.hide();
            if (onConfirm) onConfirm(confirmed);
        });
    },

    hide() {
        if (this._highlightedEl) {
            this._highlightedEl.classList.remove('vignova-jd-highlight');
            this._highlightedEl = null;
        }
        if (this._panel) {
            this._panel.remove();
            this._panel = null;
        }
    },
};

const Vignova_Overlay = {
    backdrop: null,
    overlay: null,
    _currentJobData: null,

    /**
     * Show loading state
     */
    showLoading() {
        this.remove(); // Clear any existing overlay

        // Backdrop
        this.backdrop = document.createElement("div");
        this.backdrop.className = "vignova-overlay-backdrop";
        document.body.appendChild(this.backdrop);

        // Overlay
        this.overlay = document.createElement("div");
        this.overlay.className = "vignova-overlay";
        this.overlay.innerHTML = `
            <div class="vignova-overlay-header">
                <span class="vignova-overlay-brand"><img src="${chrome.runtime.getURL('icons/logo.png')}" style="width:22px;height:22px;object-fit:contain;vertical-align:middle;margin-right:4px;"> VIGNOVA</span>
                <button class="vignova-overlay-close" id="vignova-close-overlay">✕</button>
            </div>
            <div class="vignova-overlay-body">
                <div class="vignova-overlay-loading">
                    <div class="vignova-css-spinner" style="width: 50px; height: 50px; border: 4px solid rgba(139, 92, 246, 0.2); border-left-color: #8b5cf6; border-radius: 50%; margin: 20px auto 30px auto; animation: vignova-spin 1s linear infinite;"></div>
                    <div class="vignova-overlay-loading-text">Generating Tailored Resume...</div>
                    <div class="vignova-overlay-loading-sub">AI is analyzing the job description and your profile</div>
                </div>
            </div>
        `;
        document.body.appendChild(this.overlay);

        // Close handler
        this.overlay.querySelector("#vignova-close-overlay").addEventListener("click", () => {
            this.remove();
        });

        // Click backdrop to close
        this.backdrop.addEventListener("click", () => {
            this.remove();
        });
    },

    /**
     * Show success state with tabbed results for Resume, Cover Letter, and Email
     */
    showAllResults(pdfBase64, coverLetter, email, fileName, creditsRemaining) {
        if (!this.overlay) return;

        const body = this.overlay.querySelector(".vignova-overlay-body");
        body.innerHTML = `
            <span class="vignova-overlay-success-icon">🎉</span>
            <div class="vignova-overlay-success-title">Application Pack Ready!</div>
            <div class="vignova-overlay-success-sub">Your tailored resume, cover letter, and email draft are ready.</div>
            
            <div class="vignova-result-tabs">
                <button class="vignova-rtab active" data-tab="resume">📄 Resume</button>
                <button class="vignova-rtab" data-tab="coverletter">✉️ Cover Letter</button>
                <button class="vignova-rtab" data-tab="email">📧 Email</button>
            </div>

            <div class="vignova-rtab-content active" id="vignova-rtab-resume">
                ${pdfBase64 ? `
                    <button class="vignova-overlay-download-btn" id="vignova-download-pdf">
                        📥 Download PDF
                    </button>
                ` : `
                    <div style="color: #ef4444; font-size: 13px; text-align: center; margin-bottom: 12px;">Failed to generate PDF. Resume data was saved.</div>
                `}
            </div>

            <div class="vignova-rtab-content" id="vignova-rtab-coverletter">
                ${coverLetter ? `
                    <div class="vignova-text-preview">${coverLetter.replace(/n/g, '<br>')}</div>
                    <button class="vignova-overlay-copy-btn" id="vignova-copy-cl">
                        📋 Copy Cover Letter
                    </button>
                ` : `
                    <div style="color: #ef4444; font-size: 13px; text-align: center;">Failed to generate cover letter.</div>
                `}
            </div>

            <div class="vignova-rtab-content" id="vignova-rtab-email">
                ${email ? `
                    <div class="vignova-text-preview">${email.replace(/n/g, '<br>')}</div>
                    <button class="vignova-overlay-copy-btn" id="vignova-copy-email">
                        📋 Copy Email
                    </button>
                ` : `
                    <div style="color: #ef4444; font-size: 13px; text-align: center;">Failed to generate email.</div>
                `}
            </div>

            <a href="https://app.vignova.io/dashboard" target="_blank" class="vignova-overlay-view-btn" style="margin-top:16px;">
                View in Vignova Dashboard →
            </a>
            <div class="vignova-overlay-credits">
                Credits remaining: <strong>${creditsRemaining}</strong>
            </div>
        `;

        // Tab Switching Logic
        const tabs = body.querySelectorAll('.vignova-rtab');
        const contents = body.querySelectorAll('.vignova-rtab-content');
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                tabs.forEach(t => t.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                body.querySelector(`#vignova-rtab-${tab.dataset.tab}`).classList.add('active');
            });
        });

        // PDF download handler
        if (pdfBase64) {
            body.querySelector("#vignova-download-pdf").addEventListener("click", () => {
                this._downloadPdf(pdfBase64, fileName);
            });
        }

        // Copy handlers
        const handleCopy = (btnId, text) => {
            const btn = body.querySelector(`#${btnId}`);
            if (btn) {
                btn.addEventListener("click", () => {
                    navigator.clipboard.writeText(text).then(() => {
                        const originalHtml = btn.innerHTML;
                        btn.innerHTML = "✅ Copied!";
                        setTimeout(() => btn.innerHTML = originalHtml, 2000);
                    });
                });
            }
        };

        if (coverLetter) handleCopy("vignova-copy-cl", coverLetter);
        if (email) handleCopy("vignova-copy-email", email);
    },

    /**
     * Show success state (Legacy, kept for compatibility if needed elsewhere)
     */
    showSuccess(pdfBase64, fileName, creditsRemaining) {
        if (!this.overlay) return;

        const body = this.overlay.querySelector(".vignova-overlay-body");
        body.innerHTML = `
            <span class="vignova-overlay-success-icon">🎉</span>
            <div class="vignova-overlay-success-title">Resume Ready!</div>
            <div class="vignova-overlay-success-sub">Your tailored resume has been generated and saved to your Vignova dashboard.</div>
            ${pdfBase64 ? `
                <button class="vignova-overlay-download-btn" id="vignova-download-pdf">
                    📥 Download PDF
                </button>
            ` : `
                <a href="https://app.vignova.io/dashboard" target="_blank" class="vignova-overlay-download-btn">
                    Open Dashboard
                </a>
            `}
            <a href="https://app.vignova.io/dashboard" target="_blank" class="vignova-overlay-view-btn">
                View in Vignova Dashboard →
            </a>
            <div class="vignova-overlay-credits">
                Credits remaining: <strong>${creditsRemaining}</strong>
            </div>
        `;

        // PDF download handler
        if (pdfBase64) {
            body.querySelector("#vignova-download-pdf").addEventListener("click", () => {
                this._downloadPdf(pdfBase64, fileName);
            });
        }
    },

    /**
     * Show error state
     */
    showError(errorMessage, retryCallback) {
        if (!this.overlay) {
            this.showLoading(); // Create overlay if not exists
        }

        const body = this.overlay.querySelector(".vignova-overlay-body");
        body.innerHTML = `
            <span class="vignova-overlay-error-icon">⚠️</span>
            <div class="vignova-overlay-error-title">Generation Failed</div>
            <div class="vignova-overlay-error-msg">${errorMessage}</div>
            ${retryCallback ? '<button class="vignova-overlay-retry-btn" id="vignova-retry-btn">🔄 Try Again</button>' : ""}
        `;

        if (retryCallback) {
            body.querySelector("#vignova-retry-btn").addEventListener("click", () => {
                retryCallback();
            });
        }
    },

    /**
     * Download PDF from base64
     */
    _downloadPdf(base64, fileName = "resume.pdf") {
        const byteCharacters = atob(base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: "application/pdf" });

        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    /**
     * Remove overlay from DOM
     */
    remove() {
        if (this.backdrop) {
            this.backdrop.remove();
            this.backdrop = null;
        }
        if (this.overlay) {
            this.overlay.remove();
            this.overlay = null;
        }
    },
};

// Expose on window so consumer scripts (linkedin.js / indeed.js) can resolve
// the overlay defensively instead of crashing with a ReferenceError if this
// file ever fails to load (partial injection after an extension update, etc.)
window.Vignova_Overlay = Vignova_Overlay;
